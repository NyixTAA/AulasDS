package calculadora;

public class calcular {

    public static String valor;
    
    public static String funcChamada(String operacao){
        valor = operacao;
        return valor;
    }
}
