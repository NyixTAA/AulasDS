/**
 *
 * @author Davi Ramos
 * 
 */

public class ex12 {
    public static void main(String[] args) {
        int num = 8;

        for(int i=0; i<=10; i++ ){
            System.out.println("Tabuada " +num*i);
        }
    }
}
