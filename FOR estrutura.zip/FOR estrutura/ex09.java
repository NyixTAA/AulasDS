/**
 *
 * @author Davi Ramos
 * 
 */

 public class ex09 {
    public static void main(String[] args) {
    
        int num = 110;
         
        for( int i = 100; i <= num; i ++){
            
            if(i == 100){
                
                i++;
                
            }
            
        System.out.println("OS 10 primeiros números inteiros maiores que 100: " + i);  
}
    
}
}
